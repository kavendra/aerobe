@extends('layouts.app')
@section('content')
<div class="top-banner csr-banner hub">
	<div class="container">
		<div class="textb2">
			<h2>Knowledge Hub</h2>
			<p>Keep yourself more updated</p>
		</div>
		<div class="rightb">
			<div class="whiteb">
				<span class="tag-text">Tecnology</span>
				<h3>The Impact of Technology on <br/> the Workplace: How <br/> Technology is Changing</h3>
			</div>
		</div>
	</div>
</div>

<div class="mid-section">
  <div class="latest-post">
    <div class="container">
      <h2>Latest Post</h2>
      <div class="top-row">
        <div class="left-tab">
          <ul>
            <li><button type="button" class="btn active" data-target="viewall"><div id="total-academy"></div></button></li>
            @foreach($knowledgeHubs as $aerobeAcademic)
              @if($aerobeAcademic->first() && $aerobeAcademic->first()->category)
               <li><button type="button" class="btn academy-count" data-count="{{ $aerobeAcademic->count() }}" data-target="cate-{{ $aerobeAcademic->first()->category->label }}">{{ $aerobeAcademic->first()->category->label }} ({{ $aerobeAcademic->count() }})</button></li>
              @endif
            @endforeach
          </ul>
        </div>
        <div class="right-tab">
          <ul>
            <li class="active" id="gridBtn"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"><rect width="7" height="7" x="3" y="3" rx="1"></rect><rect width="7" height="7" x="14" y="3" rx="1"></rect><rect width="7" height="7" x="14" y="14" rx="1"></rect><rect width="7" height="7" x="3" y="14" rx="1"></rect></svg></li>
            <li id="listBtn"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"><line x1="8" x2="21" y1="6" y2="6"></line><line x1="8" x2="21" y1="12" y2="12"></line><line x1="8" x2="21" y1="18" y2="18"></line><line x1="3" x2="3.01" y1="6" y2="6"></line><line x1="3" x2="3.01" y1="12" y2="12"></line><line x1="3" x2="3.01" y1="18" y2="18"></line></svg></li>
          </ul>
        </div>
      </div>

      @foreach($categories as $category)  
      <div class="items-container grid-view active" id="cate-{{ $category->label }}">
        @if(isset($knowledgeHubs[$category->id]))
         @foreach($knowledgeHubs[$category->id] as $knowledgeHub)
         <div class="item">
          <div class="imgb">
            <a href="{{ route('knowledge-hub.show', $knowledgeHub) }}" target="_blank">
               @if ($knowledgeHub->image && file_exists(public_path('assets/uploads/knowledge-hubs/' . $knowledgeHub->image)))
                  <img src="{{ asset('assets/uploads/knowledge-hubs/'.$knowledgeHub->image) }}" />
               @else
                  <img src="{{ asset('img/img-dummy.jpg') }}" class="rounded me-2" title="Site Logo" width="150" height="120"  data-holder-rendered="true" />
               @endif
            </a>
          </div>
          <div class="textb">
            <span class="tag-text">{{ $category->label }}</span>
            <h3><a href="{{ route('knowledge-hub.show', $knowledgeHub) }}" target="_blank">{{ $knowledgeHub->title }}</a></h3>
            <p style="display: block;"> {{ $knowledgeHub->short_description }}</p>
            <div class="review">
              <a href="{{ route('knowledge-hub.show', $knowledgeHub) }}" target="_blank">Read More</a>
            </div>
          </div>
        </div>
        @endforeach
        @endif
        </div>
      @endforeach
    </div>
  </div>
</div>
<script type="text/javascript">
var sum = 0;
$('.academy-count').each(function(){
    sum += parseFloat($(this).data('count'));  // Or this.innerHTML, this.innerText
});
$('#total-academy').html('All ('+sum+ ')');
</script>
@endsection