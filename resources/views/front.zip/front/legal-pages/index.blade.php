@extends('layouts.app')
@section('content')
<div class="mid-section">
    <div class="common-text">
        <div class="container">
            {!! $desc !!}
        </div>
    </div>
</div>
@endsection